const express = require('express');
const promotionRouter = express.Router();
const Promotion = require('../models/promotion');

promotionRouter.route('/')
    .get((req, res, next) => {
        promotion.find()
        .then(promotions => res.status(200).json(promotions))
        .catch(err => next(err))
})

.post((req, res) => {
    Promotion.create(req.body)
    .then(promotion => res.status(201).json(promotion))
    .catch(err => next (err))
})
.put((req, res) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /promotions');
})
.delete((req, res, next) => {
    promotion.deleteMany()
    .then(promotions => res.status(200).json(promotions))
    .catch(err => next(err))
});

promotionRouter.route('/:promotionId')
.get((req, res, next) => {
    promotion.findById(req.params.promotionId)
    .then(promotion => res.status(200).json(promotion))
    .catch(err => next (err))
})
    
    .post((req, res) => {
        res.statusCode = 403;
        res.end('POST request not supported on /promotions/${req.params.promotionId}');
    })
    .put((req, res, next) => {
        promotion.findByIdAndUpdate(req.params.promotionId, req.body, { new: true })
        .then(promotion => res.status(200).json(promotion))
        .catch(err => next (err))
    })
    .delete((req, res, next) => {
        promotion.findByIdAndDelete(req.params.promotionId)
        .then(promotion => res.status(200).json(promotion))
        .catch(err => next(err))
    });

module.exports = promotionRouter;