const mongoose = require('mongoose');
const schema = mongoose.Schema;

const partnerSchema = new Schema({
    name:{
        type: String,
        required: true,
        unique: true
    },
    image: {
        type: String,
        required: true
    },
    featured: {
        type: Boolean,
        default: false
    },
    description: {
        type: String,
        required: true
    }
}, {
    timestamps: trrue
});

module.exports = mongoose.model('Partner', partnerSchema);